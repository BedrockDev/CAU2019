#include <stdio.h>

int main() {
	int data1 = 10, data2 = 20;
	int* p1 = &data1, * p2 = &data2;

	printf("data1 using data1 = %d\tdata2 using data2 = %d\n", data1, data2);
	printf("data1 using *p1 = %d\tdata2 using *p2 = %d\n", *p1, *p2);

	return 0;
}